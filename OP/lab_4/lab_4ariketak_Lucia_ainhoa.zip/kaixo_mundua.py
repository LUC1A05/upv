def kaixo_mundua():
    print ("kaixo mundua")
kaixo_mundua()
