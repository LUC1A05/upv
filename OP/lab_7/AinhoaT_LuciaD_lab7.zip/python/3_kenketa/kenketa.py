def idatzi_osoko_handia(zenb):
   print(zenb)
#zenb-n gordetako osoko handiko zifrak inprimatuko ditu
# ezkerretik eskumara (ezkerreko zeroak ez dira inprimatuko) 
# adib.   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 9, 9, 9, 9, 9, 9, 9,
#         9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
#         9, 9, 9, 9, 9, 9, 9, 9, 9, 9
   
def handiago(zenb1,zenb2):

# Aurre: zenb1 eta zenb2 positiboak dira eta len(zenb1)=len(zenb2)
# Post: emaitza true zenb1 > zenb2 denean bestela False
     i=0
     while i < len(zenb1):
        if zenb1[i] > zenb2[i]:
           han=True
           return han
        elif zenb1[i]<zenb2[i]:
           han=False
           return han
        i+=1
   
def kenketa(zenb1,zenb2):
#Aurre: zenb1 eta zenb2 positiboak dira eta zenbakirik ez dauden ezker posizioetan 0koak daude
#Post: zenb2 > zenb1 bada emaitza 0 da, bestela, zenb1 - zenb2 izango da
     emaitza = [0]*len(zenb1)
     sob = 0
     if not handiago(zenb1,zenb2):
      return emaitza
     else:
          for i in range(len(zenb1)-1, -1, -1):
               dif=zenb1[i]-zenb2[i]-sob
               if dif < 0:
                    dif +=10
                    sob=1
               else:
                    sob=0
               emaitza[i] = dif
     return emaitza

def proba():
    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 8, 8, 8, 1, 2, 3, 5, 5, 5)
    zenb2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 4, 4, 4, 1, 2, 3, 5, 5, 5)
    print("1. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 444000000 eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))

    
    
    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 9, 9, 9, 9, 9, 9, 9,
         9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
         9, 9, 9, 9, 9, 9, 9, 9, 9, 9)
    zenb2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 1)
    print("2. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 999999999999999999999999998 eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))
    
    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 9, 9, 9, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    zenb2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 1);    
    print("3. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 99899999999999999999999999999 eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))
    
    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 9, 9, 9, 0, 0, 0, 0, 0, 0,
         2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
         2, 2, 2, 2, 2, 2, 2, 2, 2, 2)
    zenb2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7)
    
    print("4. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 99899999944444444444444444445 eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))
    
    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7)
    zenb2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 9, 9, 9, 0, 0, 0, 0, 0, 0,
         2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
         2, 2, 2, 2, 2, 2, 2, 2, 2, 2)
	
    print("5. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 0 (zenb2 > zenb1 delako) eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))    
    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    zenb2= (0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0);    

    print("6. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 0 (zenb2 > zenb1 delako) eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2)) 

    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 1)
    zenb2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 2)
    print("7. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 0 (zenb2 > zenb1 delako) eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))
    
    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 1)
    zenb2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    print("8. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 1 eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))

    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 9, 9, 9, 9, 9, 9)
    zenb2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 9, 9, 9, 9, 9, 8)
    print("9. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 1 eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))
    
    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 9, 9, 9, 9, 9, 8)
    zenb2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 9, 9, 9, 9, 9, 9)
    print("10. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 0 eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))

    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 9, 9, 9, 9, 9, 9)
    zenb2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 9, 9, 9, 9, 9, 9)
    print("11. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 0 eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))

    zenb1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 1, 2, 3)
    zenb2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 1, 1, 4)
    print("12. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan beharko litzateke 9 eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))

    zenb1= ()
    zenb2= ()
    print("13. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza izan hutsik egon beharko luke eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))

    zenb1= (1,2,3)
    zenb2= (1,2,-1)
    print("14. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza 4 izan beharko litzateke eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))
    
    zenb1= (1,2,3)
    zenb2= (1,2,4)
    print("15. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza 0 izan beharko litzateke eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))
    
    zenb1= (2,0)
    zenb2= (1,0)
    print("16. proba.")
    print("==============")
    idatzi_osoko_handia(zenb1)
    print(" ken ")
    idatzi_osoko_handia(zenb2)
    print("\n")
    print("Emaitza 10 izan beharko litzateke eta da: ")
    idatzi_osoko_handia(kenketa(zenb1, zenb2))
proba()