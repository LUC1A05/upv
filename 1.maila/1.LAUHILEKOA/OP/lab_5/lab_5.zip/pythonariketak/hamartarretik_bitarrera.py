def hamartarretik_bitarrera(num):
    lag=num;
    bitar=0;
    kont=0;
    
    while (lag > 0):
        bitar = lag % 2 *(10**kont) + bitar;
        lag = lag // 2;
        kont = kont + 1;
  

    return bitar

def proba():
    #1. Proba
    hamartar=1
    emaitza=hamartarretik_bitarrera(hamartar)
    pantaila='Hamartarra 1 da eta programak 1 bueltatu behar du. '+str(emaitza)+' bueltatzen du.'
    print(pantaila)
    
    #2. Proba
    hamartar=2
    emaitza=hamartarretik_bitarrera(hamartar)
    pantaila='Hamartarra 2 da eta programak 10 bueltatu behar du. '+str(emaitza)+' bueltatzen du.'
    print(pantaila)
    
    #3. Proba
    hamartar=5
    emaitza=hamartarretik_bitarrera(hamartar)
    pantaila='Hamartarra 5 da eta programak 101 bueltatu behar du. '+str(emaitza)+' bueltatzen du.'
    print(pantaila)
    
    #4. Proba
    hamartar=24
    emaitza=hamartarretik_bitarrera(hamartar)
    pantaila='Hamartarra 24 da eta programak 11000 bueltatu behar du. '+str(emaitza)+' bueltatzen du.'
    print(pantaila)
    
    #5. Proba
    hamartar=127
    emaitza=hamartarretik_bitarrera(hamartar)
    pantaila='Hamartarra 127 da eta programak 1111111 bueltatu behar du. '+str(emaitza)+' bueltatzen du.'
    print(pantaila)
    
    #6. Proba
    hamartar=146
    emaitza=hamartarretik_bitarrera(hamartar)
    pantaila='Hamartarra 146 da eta programak 10010010 bueltatu behar du. '+str(emaitza)+' bueltatzen du.'
    print(pantaila)

proba()
