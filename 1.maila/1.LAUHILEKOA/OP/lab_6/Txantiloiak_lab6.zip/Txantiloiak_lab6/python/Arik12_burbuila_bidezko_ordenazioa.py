def bektorea_idatzi(bek):
	??????????    


def bulbuila_bidezko_ordenazioa(bek):
    ????
    
    return(V)

def nagusia():
    #Kasua 1 
     bektorea1 = [9, 5, 3, 4, 10, 8, 13, 24, 15, 11]
     
     print("Hasierako bektorea (9,5,3,4,10,8,13,24,15,11):")
     bektorea_idatzi(bektorea1)

     bektorea1=bulbuila_bidezko_ordenazioa(bektorea1)
     print("Bukaerako bektorea honako beharko luke (3,4,5,8,9,10,11,13,15,24) eta emaitza:")
     bektorea_idatzi(bektorea1)

     # Proba kasuak falta dira
        
nagusia()
