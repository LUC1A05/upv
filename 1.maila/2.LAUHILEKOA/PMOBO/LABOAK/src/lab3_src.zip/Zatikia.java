package org.pmobo.packlaborategia3;


public class Zatikia implements IZatikia
{       //atributuak
	????? zenbakitzailea;
	????? izendatzailea;
	
	public Zatikia(????????)
	{
		?????
		if (pIzen ?????)
			{
				???????
			}
		else
		{
			System.out.println("Ezin daiteke izendatzailearen balioa 0 izan dezakeen zatikirik sortu ...");
		}
	}


	public int getZenbakitzailea()
	{
		//?????????????
	}

	public int getIzendatzailea()
	{
		//?????????????
	}
		
	// metodo hau ezkutatzea komeni da, pribatua egitea!
	private int zkh()
	{/**
         /* zatitzaile komunetako handiena topatu
         **/
		//TODO
	}
	
	public void sinplifikatu()
	{
		//TODO
	}
		
	public Zatikia gehitu(Zatikia pZatikia)
	{
		//TODO
	}
	
	
	public Zatikia kendu(????)
	{
		//TODO
	}
	
	public Zatikia biderkatu(????)
	{
		//TODO	
	}
	
	public Zatikia zatitu(????)
	{
		//TODO	
	}
	
	public boolean berdinaDa(????)
	{
		//TODO
	}
			
	public ???? handiagoaDa(????)
	{
		//TODO
	}
	
	public ???? txikiagoaDa(????)
	{
		//TODO
	}
        public ???? izendatzaileBerdinaDu(????){
		//TODO
	}	
        public ???? zenbakitzaileBerdinaDu(????){
		//TODO
	}	
}
