package org.pmobo.packlaborategia7;

import java.util.ArrayList;

public class ListaParteHartzaileak
{
	// atributuak
	
	
	// eraikitzailea
	
	/**
	 * post: hasieratzen du parte hartzaileen zerrenda (huts zerrenda bat bezala)
	 */
	public ListaParteHartzaileak()
	{
	
	}
	
	// beste metodoak
	
	/**
	 * @return zerrendako pPos posizioan dagoen parte hartzailea
	 *   post:  pPos parametroa balioduna ez bada,  mezu bat pantailaratzen da kontsolatik eta null bueltatzen da
	 *          Zerrendako posizioak 0-tik hasten dira eta (n-1)ean bukatzen dira, n baldin badira zerrendan
	 *          dauden parte hartzaileak 
	 *         
	 */
	public ParteHartzailea getParteHartzaileaPosizioan(int pPos)
	{
	
	}
	
	/**
	 * @return zerrendan dagoen parte hartzaileen kopurua
	 */
	public int parteHartzaileenKopurua()
	{
	
	}

		
	/**
	 * @return zerrendan dagoen Tronularien parte hartzaileen kopurua
	 */
	public int tronularienKopurua()
	{
	
	}
	
	/**
	 * @return zerrendan dagoen Pretendenteen parte hartzaileen kopurua
	 */
	public int pretendenteenKopurua()
	{

	}
	
	/**
	 * @param pParteHartzailea
	 *            post: pParteHartzailea gehitzen du zerrendan
	 */
	public void gehitu(ParteHartzailea pParteHartzailea)
	{
	
	}

	/**
	 * @param pParteHartzailea
	 * @return pParteHartzailea zerrendan dagoen ala ez esaten digun boolearra 
	 */
	public boolean baDago(ParteHartzailea pParteHartzailea)
	{
	
	}
}
