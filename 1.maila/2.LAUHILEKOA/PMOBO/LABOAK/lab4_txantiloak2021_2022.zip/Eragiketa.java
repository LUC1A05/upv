package org.pmobo.packlaborategia4;

public class Eragiketa
{
	// atributuak
	private int id;
	private int idBezeroa;
	private String pasahitza;
	private double diruKop;
	private static double komisioa = 0.1;

	// eraikitzailea
	public Eragiketa(int pId, int pIdBezeroa, String pPasaHitza, double pDiruKop)
	{
		// atributuak hasieratzeko bezainbeste parametro jasoko ditu.
	
		
		//TODO
	}

	// getters && setters

	private int getIdEragiketa()
	{
		//TODO
	}

	private int getIdBezeroa()
	{
		//TODO
	}

	private double getKopurua()
	{
		//TODO
	}

	private static double getKomisioa()
	{
		//TODO
	}

	private String getPasahitza()
	{
		//TODO
	}

	// gainotzeko metodoak
	public boolean idBerdinaDu(int pId)
	{
		boolean emaitza = false;
		//TODO
		return emaitza;
	}

	public void eragiketaBurutu()
	{
		double dirua;
		//TODO
	}
}
