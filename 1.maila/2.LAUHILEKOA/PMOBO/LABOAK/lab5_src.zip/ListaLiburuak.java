package org.pmobo.packlaborategia5;


import java.util.ArrayList;
import java.util.Iterator;

public class ListaLiburuak
{
   // atributuak
	

	// eraikitzailea
	
	public ListaLiburuak()
	{
		
	}

	// beste metodoak
	
	public int listarenTamaina()
	{  
		
	}
	 
	private Iterator<Liburua> getIteradorea()
	{
	}
  
	public Liburua bilatuLiburuaIdz(int pIdLiburua)
	{
	  
	}
  
	public boolean badago(Liburua pLiburua)
	{
		
	}
	
	public boolean idBerdinekoLibururikBaAlDa(Liburua pLiburua)
	{
		
	}
	
	public void gehituLiburua(Liburua pLiburua)
   {
	  
   }
	
	public void kenduLiburua(Liburua pLiburua)
    {
		
	}
	
	public void inprimatu()
	{
	
	}
 }
