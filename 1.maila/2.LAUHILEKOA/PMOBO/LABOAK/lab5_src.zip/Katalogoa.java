package org.pmobo.packlaborategia5;

public class Katalogoa
{
	// atributuak
	
	
	// eraikitzailea
	
	private Katalogoa()
	{
		
	}

 	// beste metodoak
 	
	public static Katalogoa getKatalogoa() 
	{
		
	}
	
 	public int liburuKopuru()
 	{
 	
 	}
 	 	
 	public Liburua bilatuLiburuaIdz(int pIdLiburua)
 	{
 	 	
 	}
 	
 	public void mailegatuLiburua(int pIdLiburua, int pIdErabiltzailea)
	{
		
	}

 	public void itzuliLiburua(int pIdLiburua)
	{
		
	}
 	
 	public void katalogatuLiburua(Liburua pLiburua)
 	{		
 		
 	}

 	public void deskatalogatuLiburua(int pIdLiburua)
 	{
	
 	}

 	public void inprimatu()
 	{
 		
 	}

 	public void erreseteatu()
 	{
 		
 	}
 	
}	
