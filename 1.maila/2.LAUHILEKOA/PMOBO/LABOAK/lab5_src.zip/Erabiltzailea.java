package org.pmobo.packlaborategia5;

public class Erabiltzailea
{
	//atributuak

	
	//eraikitzailea
	
	public Erabiltzailea(String pIzenOsoa, int pIdErabiltzaile)
	{
		
	}
	
	// beste metodoak
	
	public boolean idHauDu(int pId)
	{
	
	}
	
	public boolean idBerdinaDute(Erabiltzailea pErabiltzailea)
	{
	
	}
	
	public boolean mailegatzekoMaximoaGainditua()
	{
		
	}
	
	public void gehituLiburua(Liburua pLiburua)
	{
		
	}
	
	public void kenduLiburua(Liburua pLiburua)
	{
		
	}
	
	public boolean maileguanDu(Liburua pLiburua)
	{
		
	}
	
	public void inprimatu()
	{
		
	}

}
