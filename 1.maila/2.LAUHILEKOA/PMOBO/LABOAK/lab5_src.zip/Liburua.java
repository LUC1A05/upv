package org.pmobo.packlaborategia5;

public class Liburua
{
	
	// atributuak
	

	// eraikitzailea
	public Liburua(String pTitulua, String pIdazlea, int pIdLiburua)
	{
	
	} 
	
	// beste metodoak
	
	public boolean idHauDu(int pIdLiburua)
	{
	
	}
	
	public boolean idBerdinaDute (Liburua pLiburua)
	{
		
	}
	
	public void inprimatu() {
		
	}
	
}
