package org.pmobo.packlaborategia5;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaErabiltzaileak
{
	// atributuak
	
	
	// eraikitzailea
	
    private ListaErabiltzaileak()
    { 
    	
    }
   	
    // beste metodoak
    
   	public static ListaErabiltzaileak getListaErabiltzaileak()
   	{
   		
   	}
   	
	public int erabiltzaileKopurua()
   	{
	 
   	}
   	
   	private Iterator<Erabiltzailea> getIteradorea()
   	{
   		
   	}
    
   	public Erabiltzailea bilatuErabiltzaileaIdz(int pId)
   	{
   		
   	}
   	
   	public boolean badagoIdBerdinekoErabiltzailerik(Erabiltzailea pErabiltzailea)
   	{
   		
   	}
   	
   	public void erabiltzaileariAltaEman(Erabiltzailea pErabiltzailea)
   	{   		
   		
   	}

	public void erabiltzaileaBajaEman(int pIdErabiltzailea)
	{
		
   	}

   	public Erabiltzailea norkDaukaMaileguan(Liburua pLiburu)
   	{
   		
   	}

   	public void inprimatu()
   	{	
   	
   	}
   
   	public void erreseteatu()
   	{
   	
   	}
}
