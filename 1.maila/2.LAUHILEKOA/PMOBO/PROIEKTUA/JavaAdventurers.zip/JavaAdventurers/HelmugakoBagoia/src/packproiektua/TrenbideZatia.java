package packproiektua;

public abstract class TrenbideZatia 
{
	protected Inprimatzailea in = Inprimatzailea.getInprimatzailea();
	protected abstract void inprimatuZatia();
}
