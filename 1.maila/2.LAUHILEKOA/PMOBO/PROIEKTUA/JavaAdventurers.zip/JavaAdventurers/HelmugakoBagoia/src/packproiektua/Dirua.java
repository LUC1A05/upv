package packproiektua;

public class Dirua extends ZatiMota
{
	private int balioa;
	
	public Dirua(int diruaBalioa)
	{
		this.balioa = diruaBalioa;
	}
	public int getBalioa()
	{
		return this.balioa;
	}
}
