package packproiektua;

public class Oztopoa extends ZatiMota
{
	
}
