package packproiektua;

public class ZatiMota 
{

}
