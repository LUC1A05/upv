package packproiektua;

public class TrenbideBat extends TrenbideZatia
{
	@Override
	public void inprimatuZatia()
	{
		in.inprimatuBat();
	}
}
