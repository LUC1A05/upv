package packexceptions;

public class NotInRangeException extends Exception
{
	public NotInRangeException() 
	{
		super();
	}
}
