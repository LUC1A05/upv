package packproiektua;


public class Main 
{
	public static void main(String[] args)
	{
		HelmugakoBagoia hb = new HelmugakoBagoia();
		hb.partidaHasi();
	}
}

