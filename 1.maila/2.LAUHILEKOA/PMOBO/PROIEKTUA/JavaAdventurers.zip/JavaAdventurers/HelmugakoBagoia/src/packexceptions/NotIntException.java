package packexceptions;

public class NotIntException extends Exception
{
	public NotIntException() {
		super();
	}
}
