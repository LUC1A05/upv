package KoloreenJokoa;

public class Jokaldi {
	int dado1;
	int dado2;
	public Jokaldi(int d1, int d2) {
		this.dado1 = d1;
		this.dado2 = d2;
	}
}
