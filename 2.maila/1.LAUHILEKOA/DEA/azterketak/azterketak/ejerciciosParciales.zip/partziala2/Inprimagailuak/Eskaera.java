package Inprimagailuak;

public class Eskaera {
	Character gertaeraMota;
	Integer inprimagailua;
	Integer lana;
	public Eskaera(char c, int i, int j) {
		this.gertaeraMota = c;
		this.inprimagailua = j;
		this.lana = i;
	}
}
