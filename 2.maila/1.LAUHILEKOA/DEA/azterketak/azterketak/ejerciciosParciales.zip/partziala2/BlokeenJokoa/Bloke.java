package BlokeenJokoa;

public class Bloke {
	int puntuak;
	int jauzia; // 0 eta 6 arteko balioa
	String norabidea; // ‘l’ -> ezkerra, ‘r’ -> eskuina 
	public Bloke(int jauz, String nora) {
		this.puntuak = 5;
		this.jauzia = jauz;
		this.norabidea = nora;
	}
}
