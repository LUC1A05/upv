package KartaJokaldia;

public class Bilara<T> {
	public Bilara() {
		// eraikitzailea
	}
	 // bilara hasieratzen du (hutsa)
	public boolean hutsaDa() {
		
	}
	 // true B hutsa baldin bada eta false bestela.
	public void txertatuEzk(T elemento) {
		
	}
	 // E elementua ezkerretik gehitu dio
	public void txertatuEsk(T elemento) {
		
	}
	 // E elementua eskuinetik gehitu dio
	public void ezabatuEzk() {
		
	}
	 // ezkerrean dagoen elementua ezabatu du
	public void ezabatuEsk() {
		
	}
	 // eskuinean dagoen elementua ezabatu du
	public T lortuEzk() {
		
	}
	 // ezkerrean dagoen elementua bueltatzen du
	public T lortuEsk() {
		
	}
	 // eskuinean dagoen elementua bueltatzen du 
}
