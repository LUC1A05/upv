package KartaJokaldia;

public class Karta {
	String palo;
	int balioa;
	
	public Karta(String pPalo, int pBalioa) {
		this.palo = pPalo;
		this.balioa = pBalioa;
	}
}
