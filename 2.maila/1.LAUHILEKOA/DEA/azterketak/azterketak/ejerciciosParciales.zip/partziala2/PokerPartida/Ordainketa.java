package PokerPartida;

public class Ordainketa {
	int ordaintzailea;
	int kobratzailea;
	int kopurua;
	
	public Ordainketa(int ord, int kob, int kop) {
		this.ordaintzailea = ord;
		this.kobratzailea = kob;
		this.kopurua = kop;
	}
}
