package Portua;

public class Eskaera {
	String kontainerKode;
	int nasa;
	
	public Eskaera(int na, String ko) {
		this.kontainerKode = ko;
		this.nasa = na;
	}
}
