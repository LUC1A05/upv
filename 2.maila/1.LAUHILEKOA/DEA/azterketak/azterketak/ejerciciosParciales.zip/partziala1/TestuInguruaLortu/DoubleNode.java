package TestuInguruaLortu;

public class DoubleNode {
	 String data;
	 DoubleNode next;
	 DoubleNode prev;
}
