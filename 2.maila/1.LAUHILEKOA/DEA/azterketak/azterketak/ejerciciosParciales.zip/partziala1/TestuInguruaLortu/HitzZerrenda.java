package TestuInguruaLortu;

public class HitzZerrenda {
	public SimpleLinkedList<String> testuinguruaLortu(String hitz, Integer n)
	 // aurre: “hitz” hitza zerrendan dago
	 // n >= 0
	 // post: “hitz” hitza eta bere aurreko eta ondorengo “n” hitzak
	 // dituen zerrenda bueltatuko da
	 // “hitz” hitza behin baino gehiagotan agertuko balitz,
	 // orduan lehen agerpena hartuko da kontuan
	 // Hitzaren aurrean (edo atzean) “n” hitz baino gutxiago
	 // baldin badaude, orduan daudenak bueltatuko dira
	
	}
}
