package TestuInguruaLortu;

public class SimpleLinkedList<String> {
	DoubleNode first;
}
