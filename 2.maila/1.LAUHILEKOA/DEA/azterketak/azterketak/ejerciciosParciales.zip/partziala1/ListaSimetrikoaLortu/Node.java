package ListaSimetrikoaLortu;

public class Node<T> {
	int data;
	Node<T>next;
	public Node(int pData) {
		data = pData;
		next = null;
	}
}
