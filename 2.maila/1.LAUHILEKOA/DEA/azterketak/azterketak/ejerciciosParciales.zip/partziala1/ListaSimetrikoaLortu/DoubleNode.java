package ListaSimetrikoaLortu;

public class DoubleNode<T> {
	T data;
	DoubleNode<T>prev;
	DoubleNode<T>next;
}
