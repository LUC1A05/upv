package lagunenZerrenda;

public class Adabegi {
	Pertsona info;
	Adabegi next;
	 public Adabegi(Pertsona p) {
		info = p;
		next = null;
		
	}
}