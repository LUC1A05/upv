package labo4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.stream.Collectors;


public class Graph {
	
	HashMap<String, ArrayList<String>> estekak;
	HashMap<String, Double>rank;
	HashMap<String, ArrayList<String>>gakoak;
	
	public void grafoaSortu(WebOrriGuztiak lista){
	    // Post: weben zerrendatik grafoa sortu da
	    //       Nodoak web izenak dira
		gakoak = new HashMap<>();
		estekak = new HashMap<>();
		for(WebOrri web : lista.getWebak()) {
			gakoak.put(web.getUrl(), web.getHitzGakoZerrenda());
			if(!estekak.containsKey(web.getUrl())){
				estekak.put(web.getUrl(), new ArrayList<String>());
				WebOrriZerrenda wz = web.getWebZerrenda();
				for(WebOrri har : wz.getWebak()) {
					estekak.get(web.getUrl()).add(har.getUrl());
				}
			}
		}
	}
	
	public void print(){
	   for (String web : estekak.keySet()){
		   System.out.println("Element: " + web + " --> ");
		   for (String irteerakoEsteka : estekak.get(web)) {
				System.out.print(irteerakoEsteka + " ### ");
		   }
	   }
	}
	
	public boolean erlazionatuta(String a1, String a2){
		if(!estekak.containsKey(a1) || !estekak.containsKey(a2)) {
			return false;
		}
		Queue<String> aztertuGabeak = new LinkedList<String>();
		HashSet<String> backPointers = new HashSet<String>();
		
		boolean aurkitua = false;
		aztertuGabeak.add(a1);
		backPointers.add(a1);
		
		while(!aztertuGabeak.isEmpty() && !aurkitua) {
			String unekoa = aztertuGabeak.peek();
			if(unekoa.equals(a2)) {
				aurkitua = true;
			}
			else if(estekak.get(unekoa) != null) {
				for(String esteka : estekak.get(unekoa)) {
					if(!backPointers.contains(esteka)) {
						backPointers.add(esteka);
						aztertuGabeak.add(esteka);
					}
				}
				aztertuGabeak.remove();
			}
		}   
		return aurkitua;
	}
	
	public ArrayList<String> erlazioBidea(String a1, String a2){
		
		Queue<String> aztertuGabeak = new LinkedList<String>();
		HashMap<String, String> backPointers = new HashMap<String,String>();
		ArrayList<String> ema = new ArrayList<String>();
		if(!estekak.containsKey(a1) || !estekak.containsKey(a2)) {
			return ema;
		}
		
		boolean aurkitua = false;
		aztertuGabeak.add(a1);
		backPointers.put(a1, null);
		
		while(!aztertuGabeak.isEmpty() && !aurkitua) {
			String unekoa = aztertuGabeak.peek();
			if(unekoa.equals(a2)) {
				aurkitua = true;
			}
			else if (estekak.get(unekoa) != null){
				for(String esteka : estekak.get(unekoa)) {
					if(!backPointers.containsKey(esteka)) {
						backPointers.put(esteka, unekoa);
						aztertuGabeak.add(esteka);
					}
				}
				aztertuGabeak.remove();
			}
		}
		String unekoa =  aztertuGabeak.peek();
		while(backPointers.get(unekoa) != null) {
			ema.add(0, unekoa);
			unekoa = backPointers.get(unekoa);
		}
		ema.add(0, unekoa);
		return ema;
	}
	
	public void inprimatuBidea(ArrayList<String> bidea) {
		for(String unekoa : bidea) {
			System.out.print(unekoa + "-->");
		}
		System.out.println();
	}
	
	public double probakEgin(int testKopurua) {
		Random random = new Random();
		ArrayList<String> gakoak = new ArrayList<String>(estekak.keySet());
		long start = System.currentTimeMillis();

		for(int i = 1; i <= testKopurua; i++) {
			String a1 = gakoak.get(random.nextInt(gakoak.size()));
			String a2 = gakoak.get(random.nextInt(gakoak.size()));
			erlazionatuta(a1 ,a2);
		}
		
		long now = System.currentTimeMillis();
		return (now - start)/1000.0;
	}
      
	public HashMap<String, Double> randomWalkPageRank(int nTests) {
        // Emaitza Random Walk algoritmoak kalkulatutako balioa izango da, sareko osagai bakoitzeko
		double d = 0.85; // damping factor
		Random r = new Random();
		HashMap<String, Double> ema = new HashMap<String, Double>();
		String[]webak = new String[estekak.size()];
		int i = 0;
        // KODEA INPLEMENTATU
		for(String web : estekak.keySet()) {
			webak[i] = web;
			ema.put(web, 0.00);
			i++;
		}
		int x = r.nextInt(webak.length);
		String unekoa = webak[x];
		for(int j = 0; j < nTests; j++) {
			boolean amaitu = false;
			HashSet<String>aztertuak = new HashSet<String>();
			aztertuak.add(unekoa);
			while(!amaitu) {
				ema.put(unekoa, ema.get(unekoa)+1.00);
				Double prob = r.nextDouble();
				if(prob < d) {
					ArrayList<String> adabegiak =  estekak.get(unekoa);
					if(!adabegiak.isEmpty() && adabegiak != null) {
						unekoa = adabegiak.get(r.nextInt(adabegiak.size()));
						if(aztertuak.contains(unekoa)){
							x = r.nextInt(webak.length);
							unekoa = webak[x];
							amaitu = true;
						}
						else {
							aztertuak.add(unekoa);
						}
					}
					else {
						x = r.nextInt(webak.length);
						unekoa = webak[x];
						amaitu = true;
					}
				}
				else {
					x = r.nextInt(webak.length);
					unekoa = webak[x];
					amaitu = true;
				}
			}
		}
		rank = ema;
		return ema;
     }
       
     public HashMap<String, Double> pageRank() {
       //POST: emaitza web-orri zerrendaren web-orri bakoitzaren PageRank algoritmoaren balioa da
       
		boolean trace = false; // tracing the pagerank algorithm
		//boolean damping = true; 
		double dampingFactor = 0.85;
		double tolerantzia = 0.0001;
		//double hasierakoRank = 1.0/estekak.size();
		HashMap<String, Double> ema = new HashMap<String, Double>();
		HashMap<String, Double>aurrekoRank = new HashMap<String, Double>();	
		
        // KODEA INPLEMENTATU
		for(String web : estekak.keySet()) {
			ema.put(web, (1-dampingFactor)/estekak.size());
			aurrekoRank.put(web, 1.00/estekak.size());
		}
		boolean eginda = false;
		int iterNum = 1;
		double diff = 0.00;
		double webRank;
		while(!eginda) {
			diff = 0.00;
			for(String web : estekak.keySet()) {
				if(estekak.get(web).size() != 0) {
					webRank = dampingFactor*aurrekoRank.get(web)/estekak.get(web).size();
					for(String adabegi : estekak.get(web)) {
						ema.put(adabegi, ema.get(adabegi) + webRank);
					}
				}
			}
			if(trace) {
				System.out.println("Iterazioa " + iterNum + ": ");
				for(String web : estekak.keySet()) {
					System.out.println("-> "+ web + ": "+ String.format("%.10f", aurrekoRank.get(web)));
				}
			}
			for(String web:estekak.keySet()){
				diff += Math.abs(ema.get(web) - aurrekoRank.get(web));
				aurrekoRank.put(web,ema.get(web));	
				ema.put(web, (1-dampingFactor)/estekak.size());
			}
			if(diff < tolerantzia) {
				eginda = true;
			}
			iterNum++;
		}
		rank = aurrekoRank;
		return aurrekoRank;
	}
     
     public ArrayList<Bikote> bilatzailea(String gakoHitz1, String gakoHitz2){
    	// Post: Emaitza emandako gako-hitzak dituzten web-orrien zerrenda da,
    	// bere pagerank-aren arabera handienetik txikienera ordenatuta (hau da,
    	// lehenengo posizioetan pagerank handiena duten web-orriak agertuko dira)
    	 ArrayList<Bikote> ema = new ArrayList<Bikote>();
    	 for(String web : estekak.keySet()) {
    		 if(gakoak.get(web).contains(gakoHitz1)) {
    			 if(gakoak.get(web).contains(gakoHitz2)) {
    				 ema.add(new Bikote(web, rank.get(web)));
    			 }
    		 }
    	 }
    	 int n = ema.size();
    	 boolean aldaketa;
    	 for(int i = 0;i<n-1; i++) {
    		 aldaketa = false;
    		 for(int j = 0; j<n-i-1; j++) {
    			 if(ema.get(j).getRank() < ema.get(j+1).getRank()) {
    				 Bikote temp = ema.get(j);
    				 ema.set(j, ema.get(j+1));
    				 ema.set(j+1, temp);
    				 aldaketa = true;
    			}
    		 }
    		 if(!aldaketa) {
    			 return ema;
    		 }
    	 }
    	 return ema;
     }
       
     public void imprimirLosDeMejorPageRank(HashMap<String, Double> pr, int n) { // inefficient but valid!
       // Post: Balio handieneko elementuak inprimatuko ditu.
       //       Ez da batere eraginkorra maximoak bata bestearen atzetik kalkulatzen dituelako, eta aurreko maximoa ezabatzen du bakoitzean.
       //       Horrela, hasierako balioak ezabatzen ditu.
       //       Emaitzak bistaratzeko erabilgarria izan liteke
    	 String[]id2String = new String[estekak.size()];
    	 int i = 0;
    	 for(String web : estekak.keySet()) {
    		 id2String[i] = web;
    		 i++;
    	 }
    	 for (int x = 1; x <= n; x++) {
    		 double max = -1;
    		 int iMax = -1;
    		 for (int j = 0; j < pr.size(); j++)
    		 if (pr.get(id2String[j]) > max) {
				max = pr.get(id2String[j]);
				iMax = j;
			 }
    		 System.out.println("The " + x + " the best element is "+ id2String[iMax] + " with value " + max);
    		 pr.put(id2String[iMax], (double) -1); // delete the maximum
		}
	}
     public void inprimatuBikoteak(ArrayList<Bikote> bikZer) {
    	 int i = 1;
    	 for(Bikote bik : bikZer) {
    		 System.out.println(i+". --> "+bik.getWeb() + " orria hurrengo pageRank-a du: "+ bik.getRank());
    		 i++;
    	 }
     }
}
