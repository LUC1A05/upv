package labo4;

import static org.junit.Assert.*;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;


public class GraphTest {
	String helb = System.getProperty("user.dir"); 
	WebOrriGuztiak wog = WebOrriGuztiak.getWebOrriGuztiak(helb + File.separator + "labo4");
	Graph gr = new Graph();

	@Test
	public void test() {
		gr.grafoaSortu(wog);
		HashMap<String, Double>ema;
		ema = gr.pageRank();
		gr.imprimirLosDeMejorPageRank(ema, 11);
		ArrayList<Bikote>bikoteak = gr.bilatzailea("money", "lucia");
		gr.inprimatuBikoteak(bikoteak);
//		System.out.println();
//		ema = gr.randomWalkPageRank(40000000);
//		gr.imprimirLosDeMejorPageRank(ema, 11);
	}

}
