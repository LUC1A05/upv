package labo4;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class WebOrriGuztiak {
	
	private static HashMap<Integer, WebOrri> webOrriak;
	private static WebOrriGuztiak nireWebak = null;
	private static int idMax = 2039804;

	private WebOrriGuztiak() {
		webOrriak = new HashMap<Integer, WebOrri>();
	}
	public ArrayList<WebOrri> getWebak(){
		ArrayList<WebOrri> webak = new ArrayList<WebOrri>(webOrriak.values());
		return webak;
	}
	public static WebOrriGuztiak getWebOrriGuztiak(String pHelb) {
		if(nireWebak == null) {
			nireWebak = new WebOrriGuztiak();
			webakKargatu(pHelb);
			estekakKargatu(pHelb);
			HitzGakoZerrenda hgz = HitzGakoZerrenda.getHitzGakoZerrenda();
			hitzGakoakKargatu(hgz);
		}
		return nireWebak;
	}
	public int getIdMax() {
		return idMax;
	}
	
//============== FUNTZIOAK ==========================
//1. web orri bat emanda, honek estekatzen dituen web orrien zerrenda bueltatu
	public WebOrriZerrenda WebOrriEstekatuak (String url) {
		for(int id : webOrriak.keySet()) {
			WebOrri web = webOrriak.get(id);
			if(web.getUrl().equals(url)) {
				return web.getWebZerrenda();
			}
		}
		System.out.println("Ez dago web-ik izen horrekin.");
		return null;
	}
//2. web orri baten txertaketa
	public void webOrriaTxertatu(String url){
		idMax = idMax +1;
		if(string2Web(url) == null) {
			WebOrri pWeb = new WebOrri(url);
			HitzGakoZerrenda hgz = HitzGakoZerrenda.getHitzGakoZerrenda();
			pWeb.web2Words(hgz, pWeb);
			webOrriak.put(idMax, pWeb);
			System.out.println("Weba txertatuta");
		}
		else {
			System.out.println("Badago weba izen horrekin");
		}
	}
//3. web orria ezabatu	
	public void webOrriaEzabatu(String url){
		for(int id : webOrriak.keySet()) {
			WebOrri web = webOrriak.get(id);
			if(web.getUrl().equals(url)) {
				web.removeWeb();
				for(WebOrri webEst : webOrriak.values()) {
					if(webEst.getWebZerrenda().webOrriaDago(web.getUrl())) {
						webEst.getWebZerrenda().webOrriaEzabatu(web);
					}
				}
				webOrriak.remove(id, web);
				System.out.println("Weba ezabatuta");
				return;
			}
		}
		System.out.println("Ez dago web-ik izen horrekin.");	
	}
//5. webOrriZerrenda alfabetikoki bueltatu	
	public ArrayList<String>webOrdenatua(){
		ArrayList<String>ordenatuta=new ArrayList<>();
		for(Integer id : webOrriak.keySet()) {
			WebOrri web = webOrriak.get(id);
			ordenatuta.add(web.getUrl());
		}
		Collections.sort(ordenatuta);
		return ordenatuta;
	}
//6. GAKO HITZ BAT EMANDA GAKOA DUTEN WEB ORRIAK BUELTATU
	public HashSet<String> word2Webs(String hitza){ 
		HitzGakoZerrenda hgz = HitzGakoZerrenda.getHitzGakoZerrenda();
		if(hgz.hitzaBadago(hitza)) {
			return hgz.hitzaDutenWebakLortu(hitza);
		}
		else {
			System.out.println("Ez da hitz hori existitzen");
			return null;
		}
	}
//7. x osoko balio bat emanda, x-i dagokion webOrria itzuliko du
	public WebOrri ident2String(int x) {
		WebOrri wo = webOrriak.get(x);
		if(wo == null) {
			System.out.println("Ez da id horrekin webik aurkitu");
		}
		return wo;
	}
//8.fitxategia eguneratu
	public void fitxategiaEguneratu() {
		try {
			PrintWriter writer = new PrintWriter("index-2024-25-Eguneratuta", "UTF-8");
			for(Integer id : webOrriak.keySet()) {
				writer.println(id + "   :::   " + webOrriak.get(id).getUrl());
			}
			System.out.println("fitxategia eguneratu da.");
		}catch(IOException e) {
			System.out.println("ez da fitxategia aurkitu.");
		}
	}
	
	public void etekaGehitu(String web, String esteka) {
		WebOrri pWeb = string2Web(web);
		WebOrri pEsteka = string2Web(esteka);
		if(pWeb != null && pEsteka != null){
			pWeb.webEstekatuaGehitu(pEsteka);
		}
		else {
			if(pWeb == null) {
				System.out.println("Ez dago webik izen horrekin");				
			}
			else {
				System.out.println("Ez dago estekarik izen horrekin");					
			}
		}
	}
//============ Laguntzaileak ==========================
	
 	private static void hitzGakoakKargatu(HitzGakoZerrenda hgz) {
		for(WebOrri web : webOrriak.values()) {
			web.web2Words(hgz, web);
		}
	}
	
 	private static void webakKargatu(String pHelb) {
		try {
			Scanner webak = new Scanner(new FileReader(pHelb + File.separator + "index-2024-25"));
			String lerroa;
			while(webak.hasNext()) {
				lerroa = webak.nextLine();
				String[] parteak = lerroa.split("\\s+\\:+");
				int id = Integer.parseInt(parteak[0].trim());
				String url = parteak[1].trim();
				WebOrri web = new WebOrri(url);
				webOrriak.put(id, web);
			}
			webak.close();
		}catch(IOException e) {
			System.out.println("ez da lehenengo fitxategirik aurkitu.");
		}
	}
	
	private static void estekakKargatu(String pHelb) {
		try {
			Scanner estekak = new Scanner(new FileReader(pHelb + File.separator + "pld-arcs-1-N-2024-25"));
			String lerroa;
			while(estekak.hasNext()) {
				lerroa = estekak.nextLine();
				String[] parteak = lerroa.split("\\s++\\>+\\s+");
				int ida = Integer.parseInt(parteak[0].trim());
				if(parteak.length > 1 && webOrriak.containsKey(ida)) {
					String[] estekaId = parteak[1].split("\\s+\\#+\\s+");
					for(String esteka : estekaId) {
						int id2 = Integer.parseInt(esteka.trim());
						if(webOrriak.containsKey(id2)) {
							webOrriak.get(ida).webEstekatuaGehitu(webOrriak.get(id2));
						}
					}
				}
			}
			estekak.close();
		}catch(IOException e) {
			System.out.println("ez da bigarren fitxategirik aurkitu.");
		}
	}
	
	public WebOrri string2Web(String pWeb) {
		for(WebOrri web : webOrriak.values()) {
			if(web.getUrl().equals(pWeb)) {
				return web;
			}
		}
		return null;
	}
//============ Frogak egiteko =========================
	public void inprimatzailea(int pId) {
		if(!webOrriak.containsKey(pId)) {
			System.out.println("Ez da web hori existitzen.");
			return;
		}
		WebOrri wo = webOrriak.get(pId);
		String url = wo.getUrl();
		System.out.println("weba hurrengoa da: " + url + " eta web hauek estekatzen ditu:");
		if(wo.getWebZerrenda().getSize() == 0) {
			System.out.println("ez ditu web estekaturik.");
		}
		else {
			wo.getWebZerrenda().inprimatzailea();			
		}
		System.out.println(" eta hurrengo hitz gakoak ditu:");
		wo.inprimatuGakoak();
	}
	public void inprimatzailea(String pWeb) {
		WebOrri web = this.string2Web(pWeb);
		if(web == null) {
			System.out.println("Ez da web hori existitzen.");
			return;
		}
		String url = web.getUrl();
		System.out.println("weba hurrengoa da: " + url + " eta web hauek estekatzen ditu:");
		if(web.getWebZerrenda().getSize() == 0) {
			System.out.println("ez ditu web estekaturik.");
		}
		else {
			web.getWebZerrenda().inprimatzailea();			
		}
		System.out.println(" eta hurrengo hitz gakoak ditu:");
		web.inprimatuGakoak();
	}
}
