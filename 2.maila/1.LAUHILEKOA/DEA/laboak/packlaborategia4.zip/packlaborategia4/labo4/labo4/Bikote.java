package labo4;

public class Bikote {
	String web;
	Double pageRank;
	public Bikote(String pWeb, Double pRank) {
		web = pWeb;
		pageRank = pRank;
	}
	public String getWeb() {
		return web;
	}
	public Double getRank() {
		return pageRank;
	}
	public int compareTo(Bikote bestea) {
		return this.pageRank.compareTo(bestea.pageRank);
	}
	
}
