package labo4;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class WebOrri {
	
	private String url;
	private ArrayList<String> z;
	private WebOrriZerrenda wz;
	
	public WebOrri(String pUrl)
	{
		this.url=pUrl;
		this.z = new ArrayList<String>();
		this.wz = new WebOrriZerrenda();
	}
	
	public String getUrl() {
		return this.url;
	}
	public WebOrriZerrenda getWebZerrenda() {
		return this.wz;
	}
	public ArrayList<String>getHitzGakoZerrenda(){
		return this.z;
	}
	public void webEstekatuaGehitu(WebOrri pWeb) {
		if(!wz.webOrriaDago(pWeb.url)) {
			this.wz.webOrriaTxertatu(pWeb);	
		}
		else {
			System.out.println("esteka hori jadanik estekatuta dago.");
		}

	}
	public void setHitzGakoak(ArrayList<String> pHitzGakoak) {
		this.z = pHitzGakoak;
	}
	public void removeWeb() {
		HitzGakoZerrenda hgz = HitzGakoZerrenda.getHitzGakoZerrenda();
		for(String hitza: z) {
			hgz.getHitzGako(hitza).webOrriaEzabatu(this.url);
		}
	}
//============= FUNTZIOAK =======================	
	public WebOrriZerrenda WebOrriEstekatuak( ) {
		return wz;
	}
	
	public ArrayList<String> web2Words(HitzGakoZerrenda hgz, WebOrri wo) {
		for(int i = 3; i < 10; i++) {
			for(int j = 0; j <= url.length()-i; j++) {
				String hitza = this.url.substring(j,i+j);
				if(hgz.hitzaBadago(hitza)) {
					if(!z.contains(hitza)) {
						z.add(hitza);
						hgz.webOrriaTxertatu(wo, hitza);						
					}
				}
			}
		}
		return z;
		
	}
	
	private Iterator<String>getIteratorH(){
		return this.z.iterator();
	}
	public void inprimatuGakoak() {
		Iterator<String>itr = getIteratorH();
		String hitza;
		int i = 1;
		
		while(itr.hasNext()) {
			hitza = itr.next();
			System.out.println(i + " ---> "+ hitza);
			i++;
		}
	}

}
