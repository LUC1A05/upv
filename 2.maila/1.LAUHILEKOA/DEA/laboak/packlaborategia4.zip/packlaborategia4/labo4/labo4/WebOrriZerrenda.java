package labo4;
import java.util.ArrayList;
import java.util.Iterator;

public class WebOrriZerrenda {

	private ArrayList<WebOrri>zerrenda;

	public WebOrriZerrenda() {
		this.zerrenda = new ArrayList<WebOrri>();
	}

	private Iterator<WebOrri>getIterator(){
		return this.zerrenda.iterator();
	}

	public void webOrriaTxertatu(WebOrri pWeb){
		this.zerrenda.add(pWeb);
	}
	public void webOrriaEzabatu(WebOrri pWeb){
		this.zerrenda.remove(pWeb);
	}
	public Boolean webOrriaDago(String pUrl) {
		Iterator<WebOrri>itr = getIterator();
		WebOrri wo = null;
		while(itr.hasNext()) {
			wo = itr.next();
			if(wo.getUrl() == pUrl) {
				return true;
			}
		}
		return false;
	}


	//-----------------Frogak egiteko-------------
	public int getSize(){
		return this.zerrenda.size();
	}

	public void inprimatzailea() {
		Iterator<WebOrri>itr = getIterator();
		WebOrri wo = null;
		int i = 1;
		if(this.zerrenda.size() == 0) {
			System.out.println("ez dago hitz gako hori duen webik.");
			return;
		}
		while(itr.hasNext()) {
			wo = itr.next();
			System.out.println(i + " ---> " + wo.getUrl());
			i++;
		}
	}

	public ArrayList<WebOrri> getWebak() {
		return this.zerrenda;
	}
}
