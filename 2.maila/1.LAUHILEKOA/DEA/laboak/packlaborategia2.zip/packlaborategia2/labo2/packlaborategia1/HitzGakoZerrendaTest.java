package packlaborategia1;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class HitzGakoZerrendaTest {

	@Test
	public void testGetHitzGakoZerrenda() {
		String pHelb = System.getProperty("user.dir");
		HitzGakoZerrenda hgz = HitzGakoZerrenda.getHitzGakoZerrenda();
	}

	@Test
	public void testHitzaBadago() {
		fail("Not yet implemented");
	}

	@Test
	public void testWebaBadago() {
		fail("Not yet implemented");
	}

	@Test
	public void testHitzakGehitu() {
		fail("Not yet implemented");
	}

	@Test
	public void testWebOrriaTxertatu() {
		fail("Not yet implemented");
	}

	@Test
	public void testHitzaDutenWebakLortu() {
		fail("Not yet implemented");
	}

}
