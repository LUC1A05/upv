package packlaborategia1;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import listasSimples.OrderedDoubleLinkedList;
import listasSimples.UnorderedDoubleLinkedList;

public class WebOrri {
	
	private String url;
	private ArrayList<String> z;
	private UnorderedDoubleLinkedList<WebOrri> wz; //aldatuta 2.laborategiarekin
	
	public WebOrri(String pUrl)
	{
		this.url=pUrl;
		this.z = new ArrayList<String>();
		this.wz = new UnorderedDoubleLinkedList<WebOrri>(); //aldatuta 2.laborategiarekin
	}
	
	public String getUrl() {
		return this.url;
	}
	public UnorderedDoubleLinkedList<WebOrri> getWebZerrenda() { //aldatuta 2.laborategiarekin
		return this.wz;
	}
	public ArrayList<String>getHitzGakoZerrenda(){
		return this.z;
	}
	public void webEstekatuaGehitu(WebOrri pWeb) {//aldatuta 2.laborategiarekin
		if(!wz.contains(pWeb)) { 
			this.wz.addToRear(pWeb);
		}
		else {
			System.out.println("esteka hori jadanik estekatuta dago.");
		}

	}
	public void setHitzGakoak(ArrayList<String> pHitzGakoak) {
		this.z = pHitzGakoak;
	}
	public void removeWeb() {
		HitzGakoZerrenda hgz = HitzGakoZerrenda.getHitzGakoZerrenda();
		for(String hitza: z) {
			hgz.getHitzGako(hitza).webOrriaEzabatu(this.url);
		}
	}
//============= FUNTZIOAK =======================	
	public UnorderedDoubleLinkedList<WebOrri> WebOrriEstekatuak( ) {
		return wz;
	}
	
	public ArrayList<String> web2Words(HitzGakoZerrenda hgz, WebOrri wo) {
		for(int i = 3; i < 10; i++) {
			for(int j = 0; j <= url.length()-i; j++) {
				String hitza = this.url.substring(j,i+j);
				if(hgz.hitzaBadago(hitza)) {
					if(!z.contains(hitza)) {
						z.add(hitza);
						hgz.webOrriaTxertatu(wo, hitza);						
					}
				}
			}
		}
		return z;
		
	}
	
	private Iterator<String>getIteratorH(){
		return this.z.iterator();
	}
	private Iterator<WebOrri>getIteratorZ(){
		return this.wz.iterator();
	}
	public void inprimatuGakoak() {
		Iterator<String>itr = getIteratorH();
		String hitza;
		int i = 1;
		
		while(itr.hasNext()) {
			hitza = itr.next();
			System.out.println(i + " ---> "+ hitza);
			i++;
		}
	}
	public void inprimatuZerrenda() {
		Iterator<WebOrri>itr = this.getIteratorZ();
		String url;
		while(itr.hasNext()) {
			url =itr.next().url;
			System.out.println("--> "+url);
		}
	}

}
