package packlaborategia1;

import java.util.Scanner;

public class Teklatua {
	private Scanner s;
	private static Teklatua nireTeklatua;
	
	private Teklatua() {
		this.s = new Scanner(System.in);
	}
	
	public static Teklatua getTeklatua() {
		if(nireTeklatua == null) {
			nireTeklatua = new Teklatua();
		}
		return nireTeklatua;
	}
	
	public String stringIrakurri(String pMezua) {
		System.out.println(pMezua);
		String inp = s.nextLine();
		return inp;
	}
	
	public int intIrakurri(String pMezua, int pMax) {
		Boolean validInput = false;
		int in = -1;
		
		while(!validInput) {
			System.out.println(pMezua);
			if(s.hasNextInt()) {
				in = s.nextInt();
				s.nextLine();
				
				if(in >= 0 && in <= pMax) {
					validInput = true;
				}
				else {
					System.out.println("Sartu mesedez " + pMax + " baino txikiagoa den zenbaki bat.");
				}
			}
			else {
				System.out.println("Sartu mesedez zenbaki bat.");
				s.nextLine();
			}
		}
		return in;
	}
}
