package listasSimples;

import java.util.Iterator;

public class ProbaOrderedDoubleLinkedList {	
		
		public static void main(String[] args)  {
			
			OrderedDoubleLinkedList<Integer> l = new OrderedDoubleLinkedList<Integer>();
			l.add(1);
			l.add(3);
			l.add(6);
			l.add(30);
			l.add(7);
			l.add(9);
			l.add(0);
			l.add(20);
			l.remove(7);

			
			System.out.print(" Lista ...............\n");
			l.adabegiakInprimatu();
			System.out.println(" Elementu-kopurua: " + l.size());
					
			
			System.out.println("Proba Find ...............");
			System.out.println("20? " + l.find(20));
			System.out.println("9? " + l.find(9));
			System.out.println("9? " + l.find(9));
			System.out.println("0? " + l.find(0));
			System.out.println("7? " + l.find(7));
			
			l.add(1);
			l.add(5);
			l.add(1);
			
			System.out.print(" Lista ...............\n");
			l.adabegiakInprimatu();
			System.out.println(" Elementu-kopurua: " + l.size());
			System.out.println("Proba removeAll---> Lista froga ta gero ...............");
			l.removeAll(1);
			l.adabegiakInprimatu();
			System.out.println(" Elementu-kopurua: " + l.size());
			
			OrderedDoubleLinkedList<Pertsona> l2 = new OrderedDoubleLinkedList<Pertsona>();
			l2.add(new Pertsona("jon", "1111"));
			l2.add(new Pertsona("ana", "7777"));
			l2.add(new Pertsona("amaia", "3333"));
			l2.add(new Pertsona("unai", "8888"));
			l2.add(new Pertsona("pedro", "2222"));
			l2.add(new Pertsona("olatz", "5555"));

			l2.remove(new Pertsona("", "8888"));

			
			System.out.print(" Lista ...............");
			l2.adabegiakInprimatu();
			System.out.println(" Elementu-kopurua: " + l2.size());
					
			
			System.out.println("Proba Find ...............");
			System.out.println("2222? " + l2.find(new Pertsona("", "2222")));
			System.out.println("5555? " + l2.find(new Pertsona("", "5555")));
			System.out.println("7777? " + l2.find(new Pertsona("", "7777")));	
			System.out.println("8888? " + l2.find(new Pertsona("", "8888")));	
			
			
			
			System.out.println("\n\n================================================================================= ");
			System.out.println("                            Gure probak: ");
			System.out.println("================================================================================= ");
			System.out.println("\n                          1.merge: ");
			System.out.println("================================================================================= ");
			OrderedDoubleLinkedList<Integer> l3 = new OrderedDoubleLinkedList<Integer>();
			OrderedDoubleLinkedList<Integer> l4 = new OrderedDoubleLinkedList<Integer>();
			OrderedDoubleLinkedList<Integer> l5 = new OrderedDoubleLinkedList<Integer>();
			//lista1
			l3.add(2);
			l3.add(70);
			l3.add(8);
			l3.add(1);
			l3.add(30);
			l3.add(5);
			l3.adabegiakInprimatu();
			System.out.println(" Elementu-kopurua: " + l3.size());
			
			//lista2
			l4.add(23);
			l4.add(12);
			l4.add(3);
			l4.add(6);
			l4.add(80);
			l4.adabegiakInprimatu();
			System.out.println(" Elementu-kopurua: " + l4.size());
			
			//aurreko listen batura
			l3.merge(l4);
			System.out.println("emaitza: ");
			l3.adabegiakInprimatu();
			System.out.println(" Elementu-kopurua: " + l3.size());
			System.out.println("================================================================================= ");
			
			
			System.out.println("\n                          2. removeFirst: ");
			System.out.println("================================================================================= ");
			//lista hainbat elementuekin
			l3.removeFirst();
			l3.adabegiakInprimatu();
			//lista hutsik
			l5.removeFirst();
			l5.adabegiakInprimatu();
			l5.add(555);
			//elementu bakarreko lista
			l5.removeFirst();
			l5.adabegiakInprimatu();
			System.out.println("================================================================================= ");
			
			
			System.out.println("\n                          3. removeLast: ");
			System.out.println("================================================================================= ");
			//lista haibat elementuekin
			l3.removeLast();
			l3.adabegiakInprimatu();
			//lista hutsik
			l5.removeLast();
			l5.adabegiakInprimatu();
			//elementu bakarreko lista
			l5.add(444);
			l5.removeLast();
			l5.adabegiakInprimatu();
			System.out.println("================================================================================= ");
			
			
			System.out.println("\n                          4. remove: ");
			System.out.println("================================================================================= ");
			//elementua listan dago
			l3.remove(6);
			l3.adabegiakInprimatu();
			//elementua ez dago listan
			l3.remove(1);
			//lista hutsik dago
			l5.remove(3);
			System.out.println("================================================================================= ");
			
			
			System.out.println("\n                          5. removeAll: ");
			System.out.println("================================================================================= ");
			l3.add(5);
			l3.add(5);
			l3.add(5);
			//elementua hainbat alditan errepikatzen da
			l3.removeAll(5);
			l3.adabegiakInprimatu();
			//elementu bakarra
			l3.removeAll(2);
			l3.adabegiakInprimatu();
			//elementua ez dago
			l3.removeAll(1);
			System.out.println("================================================================================= ");

			
			System.out.println("\n                          6. first: ");
			System.out.println("================================================================================= ");
			//elementua du
			System.out.println(l3.first());
			//ez du elementurik
			System.out.println(l5.first());
			System.out.println("================================================================================= ");
			
			
			System.out.println("\n                          7. last: ");
			System.out.println("================================================================================= ");
			//elementua du
			System.out.println(l3.last());
			//ez du elementurik
			System.out.println(l5.last());
			System.out.println("================================================================================= ");
			
			
			System.out.println("\n                          8. clone: ");
			System.out.println("================================================================================= ");
			l5 = l3.clone();
			System.out.println(l5.size());
			l5.adabegiakInprimatu();
			l5.remove(3);
			l5.remove(8);
			l5.remove(12);
			l5.remove(23);
			l5.remove(30);
			l5.remove(70);
			System.out.println("================================================================================= ");
			
			
			System.out.println("\n                          9. contains: ");
			System.out.println("================================================================================= ");
			//elem dago
			System.out.println(l3.contains(3));
			//elem ez dago
			System.out.println(l3.contains(4));
			System.out.println("================================================================================= ");
			
			
			System.out.println("\n                          10. find: ");
			System.out.println("================================================================================= ");
			//elem dago
			System.out.println(l3.find(3));
			//elem ez dago
			System.out.println(l3.find(4));
			System.out.println("================================================================================= ");
			
			
			System.out.println("\n                          11. is empty: ");
			System.out.println("================================================================================= ");
			//ez hutsa
			System.out.println(l3.isEmpty());
			//hutsa
			System.out.println(l5.isEmpty());
			System.out.println("================================================================================= ");
			
			
			System.out.println("\n                          12. size: ");
			System.out.println("================================================================================= ");
			System.out.println(l3.size());
			System.out.println(l5.size());
			System.out.println("================================================================================= ");
			
			System.out.println("\n                          13. iterator: ");
			System.out.println("================================================================================= ");
			Iterator<Integer>iter = l3.iterator();
			while(iter.hasNext()) {
				System.out.print(iter.next() +"|| -->||");
			}
			System.out.println("================================================================================= ");
	}
}


