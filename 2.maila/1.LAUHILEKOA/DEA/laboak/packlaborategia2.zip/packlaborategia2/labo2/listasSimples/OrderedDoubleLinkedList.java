package listasSimples;

public class OrderedDoubleLinkedList<T> extends DoubleLinkedList<T> implements OrderedListADT<T> {
	
	public void add(T elem){
		// KODEA OSATU ETA KOSTUA KALKULATU: O(n) non n elementu kopurua den. Izan ere, elementu guztiak zeharkatuko ditu kasurik txarrenean, hau da, kokatu nahi den elementua listan dauden elementu guztiak baino handiagoa bada.
		Nodo<T>berria = new Nodo<T>(elem);
		if(count == 0) {
			first = berria;
			last = berria;
		}
		//TODO era ordenatuan kokatu behar dira
		else {
			Nodo<T>lag = first;
			Boolean kokatuta = false;
			while(lag != null && !kokatuta) {				
				if(((Comparable<T>)lag.data).compareTo(elem) > 0) {
					if(lag == first) {
						first.prev = berria;
						berria.next = first;
						berria.prev = null;
						first = berria;
					}
					else {
						berria.next = lag;
						berria.prev = lag.prev;
						lag.prev.next = berria;
						lag.prev = berria;
					}
					kokatuta = true;
				}
				else{
					lag = lag.next;
				}
			}
			if(!kokatuta) {
				last.next = berria;
				berria.prev = last;
				last = berria;
			}
		}
		count ++;

	}

	public void merge(DoubleLinkedList<T> zerrenda){
		// KODEA OSATU ETA KOSTUA KALKULATU: O(n) non n bi zerrenden elem kopuruen batura den. Izan ere, kasurik txarrenean lehenengo listaren elementu guztiak zeharkatuko ditu bigarren listaren elementu guztiak kokatzeko.
		Nodo<T>lag = zerrenda.first;
		Nodo<T>unekoa = first;
		while(lag != null) {
			Nodo<T>lag2 = lag.next;
			
			if(unekoa == null) {
				last.next = lag;
				lag.prev = last;
				last = lag;
				lag = lag2;
			}
			else if(((Comparable<T>)unekoa.data).compareTo(lag.data) > 0) {
				if(unekoa == first) {
					first.prev = lag;
					lag.next = first;
					lag.prev = null;
					lag = first;
				}
				else {
					unekoa.prev.next = lag;
					lag.next = unekoa;
					lag.prev = unekoa.prev;
					unekoa.prev = lag;
				}
				lag = lag2;
			}
			else {
				unekoa = unekoa.next;
			}
		}
		count += zerrenda.count;
	}
	
	public OrderedDoubleLinkedList<T> clone(){
		OrderedDoubleLinkedList<T>kopia = new OrderedDoubleLinkedList<T>();
	    if(first == null) {
	    	return kopia;
	    }
	    Nodo<T>lag = first;
	    Nodo<T>nodoa = new Nodo<T>(lag.data);
	    kopia.first = nodoa;
	    kopia.last = nodoa;
	    lag = lag.next;
	    while(lag != null) {
	    	Nodo<T>nodoBerria = new Nodo<T>(lag.data);
	    	nodoa.next = nodoBerria;
	    	nodoBerria.prev = nodoa;
	    	nodoa = nodoBerria;
	    	lag = lag.next;
	    }
	    kopia.count = count;
	    return kopia;
}


}
