package listasSimples;

	public class Nodo<T>{
		public T data; 			// dato del nodo
		public Nodo<T> next; 	// puntero al siguiente nodo de la lista
		public Nodo<T> prev; 	// puntero al anterior nodo de la lista
		// -------------------------------------------------------------

		public Nodo(T dd) 		// constructor
		{
			this.data = dd;
			this.next = null;
			this.prev = null;
		}
	}

