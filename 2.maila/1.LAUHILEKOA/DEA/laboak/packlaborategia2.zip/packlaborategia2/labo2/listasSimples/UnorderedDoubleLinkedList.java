package listasSimples;

public class UnorderedDoubleLinkedList<T> extends DoubleLinkedList<T> implements UnorderedListADT<T> {
	
	public void addToFront(T elem) {
	// hasieran gehitu
		// KODEA OSATU ETA KOSTUA KALKULATU: O(1) hasieran kokatuko du beraz kostua konstantea da.
		Nodo<T> berria = new Nodo<T>(elem);
		if(first == null) {
			first = berria;
			last = berria;
		}
		else {
			first.prev = berria;
			berria.next = first;
			first = berria;	
		}
		count ++;
	}

	public void addToRear(T elem) {
	// bukaeran gehitu
		// KODEA OSATU ETA KOSTUA KALKULATU: O(n) bukaeran kokatuko du beraz kostua konstantea da.
		Nodo<T> berria = new Nodo<T>(elem);
		if(last == null) {
			last = berria;
			first = berria;
		}
		else {
			last.next = berria;//metodoa aurretik azken posizioan dagoen elementuaren next nodo berriari apuntatuko du
			berria.prev = last;//nodo berriaren prev hasierako azkenengo elementua apuntatuko du
			last = berria;
		}
		count ++;
	}
	
	public void addAfter(T elem, T target) {
		// KODEA OSATU ETA KOSTUA KALKULATU (AUKERAZKOA): O(n) non n listaren elem kopurua den. Izan ere, elementua listan ez badago edo listaren amaieran badago, bigarren elementua kokatzeko n elementu zeharkatuko ditu.
		Nodo<T>lag = first;
		Nodo<T>berria = new Nodo<T>(elem);
		Boolean aurk = false;
		while(lag != null && !aurk) {
			if(lag.data.equals(target)) {
				aurk = true;
				if(lag == last) {
					last.next = berria;
					berria.prev = last;
					last = berria;
				}
				else {
					lag.next.prev = berria;
					berria.next = lag.next;
					lag.next = berria;
					berria.prev = lag;
					aurk = true;
				}
			}
			lag = lag.next;
		}
		if(aurk) {
			count ++;
		}
		else {
			System.out.print(target + " ez da existitzen");
		}
	}
	public UnorderedDoubleLinkedList<T> clone(){
			UnorderedDoubleLinkedList<T>kopia = new UnorderedDoubleLinkedList<T>();
		    if(first == null) {
		    	return kopia;
		    }
		    Nodo<T>lag = first;
		    Nodo<T>nodoa = new Nodo<T>(lag.data);
		    kopia.first = nodoa;
		    kopia.last = nodoa;
		    lag = lag.next;
		    while(lag != null) {
		    	Nodo<T>nodoBerria = new Nodo<T>(lag.data);
		    	nodoa.next = nodoBerria;
		    	nodoBerria.prev = nodoa;
		    	nodoa = nodoBerria;
		    	kopia.last = nodoa;
		    	lag = lag.next;
		    }
		    kopia.count = count;
		    return kopia;
	}

}
