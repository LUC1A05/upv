package listasSimples;

import java.util.Iterator;


public class ProbaDoubleLinkedList {
	
	public static void visualizarNodos(UnorderedDoubleLinkedList<Integer> l) {
		Iterator<Integer> it = l.iterator();
		System.out.println();
		while (it.hasNext()) {
			Integer num = it.next();
			System.out.println(num);
		}
	}
	
	
	public static void main(String[] args)  {
		
		UnorderedDoubleLinkedList<Integer> l =new UnorderedDoubleLinkedList<Integer>();
		l.addToRear(1);
		l.addToRear(3);
		l.addToRear(6);
		l.addToRear(7);
		l.addToRear(9);
		l.addToRear(0);
		l.addToRear(20);
		l.addToFront(8);
		l.addAfter(5, 0);
		l.remove(7);

		
		System.out.print(" Lista ...............");
		visualizarNodos(l);
		System.out.println("Elementu-kopurua: " + l.size());
				
		
		System.out.println("Proba Find ...............");
		System.out.println("9? " + l.find(9));
		System.out.println("0? " + l.find(0));
		System.out.println("7? " + l.find(7));
		
		
		UnorderedDoubleLinkedList<Pertsona> l2 =new UnorderedDoubleLinkedList<Pertsona>();
		l2.addToRear(new Pertsona("Lucia", "111"));
		l2.addToRear(new Pertsona("Andrea", "112"));
		l2.addToRear(new Pertsona("Ainhoa", "121"));
		l2.addToFront(new Pertsona("pedro","333"));
		l2.addAfter(new Pertsona("xabat","167"), new Pertsona("","111"));
		l2.addAfter(new Pertsona("kepa", "221"), new Pertsona("", "121"));
		
		System.out.println("\nGure Probak");
		System.out.println("\n                          hasieraketak: ");
		System.out.println("================================================================================= ");
		UnorderedDoubleLinkedList<Integer> l3 = new UnorderedDoubleLinkedList<Integer>();
		UnorderedDoubleLinkedList<Integer> l4 = new UnorderedDoubleLinkedList<Integer>();
		UnorderedDoubleLinkedList<Integer> l5 = new UnorderedDoubleLinkedList<Integer>();
		//lista1
		l3.addToRear(2);
		l3.addToRear(70);
		l3.addToFront(8);
		l3.addAfter(1,2);
		l3.addToRear(30);
		l3.addToRear(5);
		l3.addToRear(6);
		l3.addToRear(5);
		l3.adabegiakInprimatu();
		System.out.println(" Elementu-kopurua: " + l3.size());
		
		System.out.println("================================================================================= ");
		
		
		System.out.println("\n                          2. removeFirst: ");
		System.out.println("================================================================================= ");
		//lista hainbat elementuekin
		l3.removeFirst();
		l3.adabegiakInprimatu();
		//lista hutsik
		l5.removeFirst();
		l5.adabegiakInprimatu();
		l5.addToRear(555);
		//elementu bakarreko lista
		l5.removeFirst();
		l5.adabegiakInprimatu();
		System.out.println("================================================================================= ");
		
		
		System.out.println("\n                          3. removeLast: ");
		System.out.println("================================================================================= ");
		//lista haibat elementuekin
		l3.removeLast();
		l3.adabegiakInprimatu();
		//lista hutsik
		l5.removeLast();
		l5.adabegiakInprimatu();
		//elementu bakarreko lista
		l5.addToFront(444);
		l5.removeLast();
		l5.adabegiakInprimatu();
		System.out.println("================================================================================= ");
		
		
		System.out.println("\n                          4. remove: ");
		System.out.println("================================================================================= ");
		//elementua listan dago
		l3.remove(6);
		l3.adabegiakInprimatu();
		//elementua ez dago listan
		l3.remove(3);
		//lista hutsik dago
		l5.remove(3);
		System.out.println("================================================================================= ");
		
		
		System.out.println("\n                          5. removeAll: ");
		System.out.println("================================================================================= ");
		l3.addAfter(5,70);
		l3.addToFront(5);
		l3.addToRear(5);
		//elementua hainbat alditan errepikatzen da
		l3.removeAll(5);
		l3.adabegiakInprimatu();
		//elementu bakarra
		l3.removeAll(2);
		l3.adabegiakInprimatu();
		//elementua ez dago
		l3.removeAll(3);
		System.out.println("================================================================================= ");

		
		System.out.println("\n                          6. first: ");
		System.out.println("================================================================================= ");
		//elementua du
		System.out.println(l3.first());
		//ez du elementurik
		System.out.println(l5.first());
		System.out.println("================================================================================= ");
		
		
		System.out.println("\n                          7. last: ");
		System.out.println("================================================================================= ");
		//elementua du
		System.out.println(l3.last());
		//ez du elementurik
		System.out.println(l5.last());
		System.out.println("================================================================================= ");
		
		
		System.out.println("\n                          8. clone: ");
		System.out.println("================================================================================= ");
		l5 = l3.clone();
		l5.adabegiakInprimatu();
		l5.remove(1);
		l5.remove(30);
		l5.remove(70);
		System.out.println("================================================================================= ");
		
		
		System.out.println("\n                          9. contains: ");
		System.out.println("================================================================================= ");
		//elem dago
		System.out.println(l3.contains(1));
		//elem ez dago
		System.out.println(l3.contains(4));
		System.out.println("================================================================================= ");
		
		
		System.out.println("\n                          10. find: ");
		System.out.println("================================================================================= ");
		//elem dago
		System.out.println(l3.find(1));
		//elem ez dago
		System.out.println(l3.find(4));
		System.out.println("================================================================================= ");
		
		
		System.out.println("\n                          11. is empty: ");
		System.out.println("================================================================================= ");
		//ez hutsa
		System.out.println(l3.isEmpty());
		//hutsa
		System.out.println(l5.isEmpty());
		System.out.println("================================================================================= ");
		
		
		System.out.println("\n                          12. size: ");
		System.out.println("================================================================================= ");
		System.out.println(l3.size());
		System.out.println(l5.size());
		System.out.println("================================================================================= ");
		
		System.out.println("\n                          13. iterator: ");
		System.out.println("================================================================================= ");
		Iterator<Integer>iter = l3.iterator();
		while(iter.hasNext()) {
			System.out.print(iter.next() +"|| -->||");
		}
		System.out.println("\n================================================================================= ");
}
}
