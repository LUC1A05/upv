package listasSimples;


import java.util.Iterator;
import java.util.NoSuchElementException;

public class DoubleLinkedList<T> implements ListADT<T> {
	
	// Atributuak
	protected Nodo<T> first;  // lehenengoaren erreferentzia
	protected Nodo<T> last;   // azkenengoaren erreferentzia
	protected String deskr;   // deskribapena
	protected int count;

	public DoubleLinkedList() {
		first = null;
		last = null;
		deskr = "";
		count = 0;
	}
	
	public void setDeskr(String ize) {
	  deskr = ize;
	}

	public String getDeskr() {
	  return deskr;
	}

	public T removeFirst() {
	// listako lehen elementua kendu da
	// Aurrebaldintza: 
		// KODEA OSATU ETA KOSTUA KALKULATU: O(1)
		if(first==null) {
			return null;
		}
		else if(first == last) {
			T lehena = first.data;
			first = null;
			last = null;
			count --;
			return lehena;	
		}
		else{
			T lehena = first.data;
			first = first.next;
			first.prev = null;
			count --;
			return lehena;	
		}
	}

	public T removeLast() {
	// listako azken elementua kendu da
	// Aurrebaldintza: 
		// KODEA OSATU ETA KOSTUA KALKULATU: O(1)
		if(last==null) {
			return null;
		}
		else if(first == last) {
			T lehena = first.data;
			first = null;
			last = null;
			count --;
			return lehena;	
		}
		else{
			T azkena = last.data;
			last = last.prev;
			last.next = null;
			count --;
			return azkena;
		}
    }

	public T remove(T elem) {
	// Aurrebaldintza: 
	// Balio hori listan baldin badago, bere lehen agerpena ezabatuko dut. Kendutako objektuaren erreferentzia 
        //  bueltatuko du (null ez baldin badago)
		// KODEA OSATU ETA KOSTUA KALKULATU: O(n) non n listan dauden elementu kop diren. Izan ere, kasurik txarrenean lista osoa zeharkatu beharko du elementua aurkitzeko.
		Nodo<T> lag = first;
		Boolean aurk = false;
		while(lag!=null && !aurk) {
			if(lag.data.equals(elem)) {
				aurk = true;
			}
			else {
				lag = lag.next;
			}
		}
	    if(aurk) {
	    	if(lag == null) {
	    		
	    	}
	    	if(first == lag) {
	    		first = lag.next;
	    		if(first != null) {
	    			first.prev = null;
	    		}
	    		else {
	    			last = null;
	    		}
	    	}
	    	else if(last == lag) {
	    		last = lag.prev;
	    		last.next = null;
	    	}
	    	else{
	    		lag.prev.next = lag.next;
	    		lag.next.prev = lag.prev;	
	    	}
	    	count --;
	    	return lag.data;
	    }
	    else {
	    	return null;
	    }
     }
        
    public void removeAll(T elem) {
        // Balio horretako elementu guztiak ezabatuko ditu
    	//KOSTUA: O(n) non n listan dauden elem kop diren. izan ere, lista guztia zeharkatu beharko du elementuen bila.
        Nodo<T> lag = first;
        while(lag!= null) {
        	if(lag.data.equals(elem)) {
        		if(lag == first) {
        			first = lag.next;
        			lag.next.prev = null;
        		}
        		else if(lag == last) {
        			last = lag.prev;
        			lag.prev.next = null;
        		}
        		else {
        			lag.prev.next = lag.next;
        			lag.next.prev = lag.prev;
        		}
        		count --;
        	}
        	lag = lag.next;
        }
    }

	public T first() {
	// listako lehen elementua ematen du
		//Kostua: O(1)
	      if (isEmpty())
	          return null;
	      else return first.data;
	}

	public T last() {
	// listako azken elementua ematen du
		//kostua: O(1)
		if(isEmpty()) {
			return null;
		}
		else return last.data;
	}
	
	public ListADT<T> clone() {
	// Zerrendaren kopia bat bueltatuko du (adabegi guztiak kopiatuko dira)
		//Kostua: O(n) non n listako elem kopurua den. Izan ere, listaren elementu guztiak kopiatu behar ditu.
	    DoubleLinkedList<T>kopia = new DoubleLinkedList<T>();
	    if(first == null) {
	    	return kopia;
	    }
	    Nodo<T>lag = first;
	    Nodo<T>nodoa = new Nodo<T>(lag.data);
	    kopia.first = nodoa;
	    kopia.last = nodoa;
	    lag = lag.next;
	    while(lag != null) {
	    	Nodo<T>nodoBerria = new Nodo<T>(lag.data);
	    	nodoa.next = nodoBerria;
	    	nodoBerria.prev = nodoa;
	    	nodoa = nodoBerria;
	    	lag = lag.next;
	    }
	    kopia.count = count;
	    return kopia;
	}

	public boolean contains(T elem) {
	// Egiazkoa bueltatuko du aurkituz gero, eta false bestela
		      // KODEA OSATU ETA KOSTUA KALKULATU: O(n) non n listan dauden elem kopurua den
		return find(elem)!=null;
	}

	public T find(T elem) {
	// Elementua bueltatuko du aurkituz gero, eta null bestela
		// KODEA OSATU ETA KOSTUA KALKULATU: O(n) non n listan daude elem kop den. Izan ere, kasurik txarrenean elementua n posizioan egongo da edo ez da egongo eta zerrenda osoa zeharkatuko du.
		if(isEmpty()) {
			return null;
		}
		Nodo<T>lag = first;
	    while(lag != null) {
	    	if(lag.data.equals(elem)) {
	    		return lag.data;
	    	}
	    	lag = lag.next;
	    }
	    return null;
	}

	public boolean isEmpty() 
	{ return first == null;};
	
	public int size() 
	{ return count;};
	
	/** Return an iterator to the stack that iterates through the items . */ 
	public Iterator<T> iterator() { return new ListIterator(); } 


	// an iterator, doesn't implement remove() since it's optional 
	private class ListIterator implements Iterator<T> { 
		private Nodo<T>lag;
		
		public ListIterator() {
			lag = first;
		}
		
		@Override
		public boolean hasNext() {
			return lag != null;
		}
		
		@Override
		public T next() {
			if(!hasNext()) {
				System.out.println("Ez dago elementurik");
			}
			T datua = lag.data;
			lag = lag.next;
			return datua;
		}
		// KODEA OSATU 
	} // private class
		
		
	public void adabegiakInprimatu() {
			System.out.println(this.toString());
	}

		
	@Override
	public String toString() {
			String result = "\n";
			Iterator<T> it = iterator();
			while (it.hasNext()) {
				T elem = it.next();
				result = result + "[" + elem.toString() + "] \n";
			}	
			return "DoubleLinkedList " + result;
	}

}
