package packlaborategia3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;



public class Graph {
	private HashMap<String, ArrayList<String>> estekak;
	
	public Graph(){
		this.estekak = new HashMap<String, ArrayList<String>>();
	}
	
	public void grafoaSortu(WebOrriGuztiak lista){
	    // Post: weben zerrendatik grafoa sortu da
	    //       Nodoak web izenak dira
		
		estekak = new HashMap<>();
		for(WebOrri web : lista.getWebak()) {
			if(!estekak.containsKey(web.getUrl())){
				estekak.put(web.getUrl(), new ArrayList<String>());
				WebOrriZerrenda wz = web.getWebZerrenda();
				for(WebOrri har : wz.getWebak()) {
					estekak.get(web.getUrl()).add(har.getUrl());
				}
			}
		}
	}
	
	public void print(){
	   for (String web : estekak.keySet()){
		   System.out.println("Element: " + web + " --> ");
		   for (String irteerakoEsteka : estekak.get(web)) {
				System.out.print(irteerakoEsteka + " ### ");
		   }
	   }
	}
	
	public boolean erlazionatuta(String a1, String a2){
		if(!estekak.containsKey(a1) || !estekak.containsKey(a2)) {
			return false;
		}
		Queue<String> aztertuGabeak = new LinkedList<String>();
		HashSet<String> backPointers = new HashSet<String>();
		
		boolean aurkitua = false;
		aztertuGabeak.add(a1);
		backPointers.add(a1);
		
		while(!aztertuGabeak.isEmpty() && !aurkitua) {
			String unekoa = aztertuGabeak.peek();
			if(unekoa.equals(a2)) {
				aurkitua = true;
			}
			else if(estekak.get(unekoa) != null) {
				for(String esteka : estekak.get(unekoa)) {
					if(!backPointers.contains(esteka)) {
						backPointers.add(esteka);
						aztertuGabeak.add(esteka);
					}
				}
				aztertuGabeak.remove();
			}
		}   
		return aurkitua;
	}
	
	public ArrayList<String> erlazioBidea(String a1, String a2){
		
		Queue<String> aztertuGabeak = new LinkedList<String>();
		HashMap<String, String> backPointers = new HashMap<String,String>();
		ArrayList<String> ema = new ArrayList<String>();
		if(!estekak.containsKey(a1) || !estekak.containsKey(a2)) {
			return ema;
		}
		
		boolean aurkitua = false;
		aztertuGabeak.add(a1);
		backPointers.put(a1, null);
		
		while(!aztertuGabeak.isEmpty() && !aurkitua) {
			String unekoa = aztertuGabeak.peek();
			if(unekoa.equals(a2)) {
				aurkitua = true;
			}
			else if (estekak.get(unekoa) != null){
				for(String esteka : estekak.get(unekoa)) {
					if(!backPointers.containsKey(esteka)) {
						backPointers.put(esteka, unekoa);
						aztertuGabeak.add(esteka);
					}
				}
				aztertuGabeak.remove();
			}
		}
		String unekoa =  aztertuGabeak.peek();
		while(backPointers.get(unekoa) != null) {
			ema.add(0, unekoa);
			unekoa = backPointers.get(unekoa);
		}
		ema.add(0, unekoa);
		return ema;
	}
	
	public void inprimatuBidea(ArrayList<String> bidea) {
		for(String unekoa : bidea) {
			System.out.print(unekoa + "-->");
		}
		System.out.println();
	}
	
	public double probakEgin(int testKopurua) {
		Random random = new Random();
		ArrayList<String> gakoak = new ArrayList<String>(estekak.keySet());
		long start = System.currentTimeMillis();

		for(int i = 1; i <= testKopurua; i++) {
			String a1 = gakoak.get(random.nextInt(gakoak.size()));
			String a2 = gakoak.get(random.nextInt(gakoak.size()));
			erlazionatuta(a1 ,a2);
		}
		
		long now = System.currentTimeMillis();
		return (now - start)/1000.0;
	}
}
