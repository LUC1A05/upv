package packlaborategia3;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GraphTest {
	String helb = System.getProperty("user.dir"); 
	WebOrriGuztiak wog = WebOrriGuztiak.getWebOrriGuztiak(helb + File.separator + "labo3");
	Graph gr = new Graph();

	@Test
	public void test1GrafoaSortu() {
		System.out.println("test1_GrafoaSortu");
		gr.grafoaSortu(wog);
	}

	@Test
	public void test2Print() {
		System.out.println("test2_Print");
		gr.grafoaSortu(wog);
		//gr.print();
	}

	@Test
	public void test3Erlazionatuta() {
		System.out.println("test3_Erlazionatuta");
		gr.grafoaSortu(wog);
		//erlazionatuta daude
		System.out.println(gr.erlazionatuta("0-00.pl", "0-100.com.cn"));
		//ez daude erlazionatuta
		System.out.println(gr.erlazionatuta("0-100.com.cn", "0-00.pl"));
		//elementu bera da
		System.out.println(gr.erlazionatuta("0-100.com.cn", "0-100.com.cn"));
	}

	@Test
	public void test4ErlazioBidea() {
		System.out.println("test4_ErlazioBidea");
		gr.grafoaSortu(wog);
		//erlazionatuta daude
		gr.inprimatuBidea(gr.erlazioBidea("0-00.pl", "0-100.com.cn"));
		//ez daude erlazionatuta
		gr.inprimatuBidea(gr.erlazioBidea("0-100.com.cn", "0-00.pl"));
		//elementu bera da
		gr.inprimatuBidea(gr.erlazioBidea("0-100.com.cn", "0-100.com.cn"));
		
	}

	@Test
	public void test5ProbakEgin() {
		System.out.println("test5_ProbakEgin");
		gr.grafoaSortu(wog);
		double i = gr.probakEgin(1);
		System.out.println("1: " + i + "s");
		i = gr.probakEgin(10);
		System.out.println("10: " + i + "s");
		i = gr.probakEgin(100);
		System.out.println("100: " + i + "s");
//		i = gr.probakEgin(1000);
//		System.out.println("1000: " + i + "s");
//		i = gr.probakEgin(10000);
//		System.out.println("10000: " + i + "s");
//		i = gr.probakEgin(100000);
//		System.out.println("100000: " + i + "s");
//		i = gr.probakEgin(1000000);
//		System.out.println("1000000: " + i + "s");
//		i = gr.probakEgin(10000000);
//		System.out.println("10000000: " + i + "s");
//		i = gr.probakEgin(100000000);
//		System.out.println("100000000: " + i + "s");
//		i = gr.probakEgin(1000000000);
//		System.out.println("10000000000: " + i + "s");
		
	}

}
