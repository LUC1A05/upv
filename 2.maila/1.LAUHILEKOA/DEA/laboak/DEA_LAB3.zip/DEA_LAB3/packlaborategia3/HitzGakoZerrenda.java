package packlaborategia3;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class HitzGakoZerrenda {

	private static HashMap<String, HitzGako>zerrenda;
	private static HitzGakoZerrenda nireHitzGakoZerrenda;

	private HitzGakoZerrenda() {
		zerrenda = new HashMap<String, HitzGako>();
	}
	
	public static HitzGakoZerrenda getHitzGakoZerrenda() {
		if(nireHitzGakoZerrenda == null) {
			nireHitzGakoZerrenda = new HitzGakoZerrenda();
			String pHelb = System.getProperty("user.dir");
			try {
				Scanner hitzak = new Scanner(new FileReader(pHelb + File.separator + "labo3" + File.separator +"words.txt"));
				String lerroa;
				while(hitzak.hasNextLine()) {
					lerroa = hitzak.nextLine();
					if(lerroa.length()>2) {
						zerrenda.put(lerroa, new HitzGako(lerroa));	
					}
				}
				hitzak.close();
			}catch(IOException e) {
				System.out.println("ez da hirugarren fitxategirik aurkitu.");
			}
		}
		return nireHitzGakoZerrenda;
	}
	
	public HitzGako getHitzGako(String hitza) {
		return zerrenda.get(hitza);
	}
	public Boolean hitzaBadago(String pHitza) {
		return zerrenda.containsKey(pHitza);
	}
	
	public Boolean webaBadago(String url, String hitza) {
		return zerrenda.get(hitza).webOrriaDago(url);
	}
	public void hitzakGehitu(HitzGako pHitza){
		zerrenda.put(pHitza.getHitza(), pHitza);
	}

	public void webOrriaTxertatu(WebOrri pWeb, String hitza) {
		zerrenda.get(hitza).webOrriaGehitu(pWeb.getUrl());
	}
	public HashSet<String> hitzaDutenWebakLortu(String hitza) {
		return zerrenda.get(hitza).getWebOrriZerrenda();
	}
}
