package packlaborategia3;

import java.util.HashSet;
import java.util.Iterator;

public class HitzGako {

	private String hitza;
	private HashSet<String> webOrriZerrenda;
	
	public HitzGako(String pHitza)
	{
		this.hitza = pHitza;
		this.webOrriZerrenda = new HashSet<String>();
	}

	public String getHitza(){
		return this.hitza;
	}
	public HashSet<String> getWebOrriZerrenda() {
		return this.webOrriZerrenda;
	}
	
	public void webOrriaGehitu(String pWeb) {
		this.webOrriZerrenda.add(pWeb);
	}
	public void webOrriaEzabatu(String pWeb) {
		this.webOrriZerrenda.remove(pWeb);
	}
	
	public Boolean webOrriaDago(String url) {
		return webOrriZerrenda.contains(url);
	}
	
	public void inprimatuWebZerrenda() {
		Iterator<String>itr = webOrriZerrenda.iterator();
		String web;
		int i = 1;
		
		while(itr.hasNext()) {
			web= itr.next();
			System.out.println(i + " ---> " + web);
			i++;
		}
	}
}
