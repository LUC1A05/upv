package org.dea.packlaborategia1;

import static org.junit.Assert.*;

import org.junit.Test;

public class WebOrriTest {

	@Test
	public void testWebOrri() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUrl() {
		fail("Not yet implemented");
	}

	@Test
	public void testWebOrriEstekatuak() {
		fail("Not yet implemented");
	}

	@Test
	public void testWeb2Words() {
		WebOrri wo = new WebOrri("thisisevdogcatslight.com");
		HitzGakoZerrenda hgz = HitzGakoZerrenda.getHitzGakoZerrenda();
		wo.web2Words(hgz, wo);
	}

}
