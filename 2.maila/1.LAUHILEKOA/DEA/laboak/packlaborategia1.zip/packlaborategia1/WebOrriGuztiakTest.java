package org.dea.packlaborategia1;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class WebOrriGuztiakTest {
	private WebOrriGuztiak wo;
	
	 @Before
	 public void setUp() {
		 String helb = System.getProperty("user.dir");
		 wo = WebOrriGuztiak.getWebOrriGuztiak(helb + File.separator + "datuak-2024-2025");
	 }

	@Test
	public void testGetWebOrriGuztiak() {
		WebOrri web = wo.ident2String(1);
		assertNotNull(web);
	}

	@Test
	public void testWebOrriEstekatuak() {
		System.out.println("\ntestGetWebOrriGuztiak: ");
	 	wo.WebOrriEstekatuak("0757duijiangji.com");
	}

	@Test
	public void testWebOrriaTxertatu() {
		System.out.println("\ntestWebOrriaTxertatu: ");
		//existitzen den weba txertatu: badagoela erantzun beharko luke
	 	wo.webOrriaTxertatu("19808.cn");
	 	//existitzen ez den weba txertatu
	 	wo.webOrriaTxertatu("luciaAndreaEtaAinhoarenlana.com");
	 	wo.inprimatzailea("luciaAndreaEtaAinhoarenlana.com");
	}

	@Test
	public void testWebOrriaEzabatu() {
		System.out.println("\ntestWebOrriaEzabatu: ");
		//existitzen den weba ezabatu
		wo.webOrriaEzabatu("123box.net");
		wo.inprimatzailea("123box.net");
		//existitzen ez den weba ezabatu
		wo.webOrriaEzabatu("frogadea.aal");
		//orri batean estekatuta dagoen weba ezabatu
		wo.webOrriaTxertatu("frogadea.aal");
		wo.etekaGehitu("luciaAndreaEtaAinhoarenlana.com", "frogadea.aal");
		wo.webOrriaEzabatu("frogadea.aal");	
		wo.inprimatzailea("luciaAndreaEtaAinhoarenlana.com");
	}
	
	@Test
	public void testWebOrdenatua() {
		System.out.println("\ntestWebOrdenatua: ");
		wo.webOrdenatua();
	}
	
	@Test
	public void testWord2Webs() {
		System.out.println("\ntestWord2Webs: ");
		//existitzen den hitza
	 	wo.word2Webs("lucia");
	 	HitzGakoZerrenda hgz = HitzGakoZerrenda.getHitzGakoZerrenda();
	 	hgz.getHitzGako("lucia").inprimatuWebZerrenda();
	 	//existitzen ez den hitza
	 	wo.word2Webs("andrea");
	}

	@Test
	public void testIdent2String() {
		System.out.println("testIdent2String: ");
		//existitzen ez den id bat
		wo.ident2String(90345672);
		//existitzen den id bat
	 	System.out.println(wo.ident2String(23000).getUrl());
	}
	
	@Test
	public void testFitxategiaEguneratu() {
		System.out.println("\ntestFitxategiaEguneratu: ");
	 	wo.fitxategiaEguneratu();
	}

}
