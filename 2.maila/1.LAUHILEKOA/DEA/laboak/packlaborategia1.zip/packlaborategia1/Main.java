package org.dea.packlaborategia1;

import java.io.File;

public class Main {
	public static void main(String[]args) {
		int auk;
		do {
			String helb = System.getProperty("user.dir");
			WebOrriGuztiak webak = WebOrriGuztiak.getWebOrriGuztiak(helb + File.separator + "datuak-2024-2025");
			auk = aukeratu();
			switch(auk) {
				case 1 -> webaBilatu(webak);
				case 2 -> webaTxertatu(webak);
				case 3 -> estekaGehitu(webak);
				case 4 -> webaEzabatu(webak);
				case 5 -> estekakItzuli(webak);
				case 6 -> word2Webs(webak);
				case 7 -> gorde(webak);
				case 8 -> webakAlfabetikoki(webak);
				case 9 -> webaBilatuString(webak);
			}
		}while(auk != 0);
	}

	private static void webaBilatuString(WebOrriGuztiak webak) {
		String url = Teklatua.getTeklatua().stringIrakurri("web orriaren izena jarri: ");
		WebOrri web = webak.string2Web(url);
		if(web != null) {
			System.out.println(web.getUrl() + " hurrengo web estekatuak ditu: ");
			web.getWebZerrenda().inprimatzailea();
			System.out.println(" eta hurrengo hitz gakoak ditu: ");
			web.inprimatuGakoak();
		}
		else {
			System.out.println("Ez da web hori existitzen.");
		}
		
	}

	private static void webakAlfabetikoki(WebOrriGuztiak webak) {
		webak.webOrdenatua();
	}

	private static void gorde(WebOrriGuztiak webak) {
		webak.fitxategiaEguneratu();
	}

	private static void word2Webs(WebOrriGuztiak webak) {
		String hitza = Teklatua.getTeklatua().stringIrakurri("hitza sartu: ");
		webak.word2Webs(hitza);
		HitzGakoZerrenda.getHitzGakoZerrenda().getHitzGako(hitza).inprimatuWebZerrenda();
	}

	private static void estekakItzuli(WebOrriGuztiak webak) {
		String web = Teklatua.getTeklatua().stringIrakurri("Web orriaren izena sartu: ");
		webak.WebOrriEstekatuak(web).inprimatzailea();
	}

	private static void webaEzabatu(WebOrriGuztiak webak) {
		String web = Teklatua.getTeklatua().stringIrakurri("Ezabatu nahi duzun orriaren izena sartu: ");
		webak.webOrriaEzabatu(web);
	}

	private static void estekaGehitu(WebOrriGuztiak webak) {
		String web = Teklatua.getTeklatua().stringIrakurri("Web orriaren izena sartu: ");
		String esteka = Teklatua.getTeklatua().stringIrakurri("Txertatu nahi duzun estekaren izena sartu: ");
		
		webak.etekaGehitu(web, esteka);
	}

	private static void webaTxertatu(WebOrriGuztiak webak) {
		String web = Teklatua.getTeklatua().stringIrakurri("Txertatu nahi duzun orriaren izena sartu: ");
		webak.webOrriaTxertatu(web);
	}

	private static void webaBilatu(WebOrriGuztiak webak) {
		int web = Teklatua.getTeklatua().intIrakurri("Bilatu nahi duzun webaren id-a sartu: ", webak.getIdMax());
		WebOrri ema = webak.ident2String(web);
		if(ema == null) {
			System.out.println("Ez dago webik id horrekin");
		}
		else {
			System.out.println("Weba hurrengoa da: " + ema.getUrl() + " Hurrengo webak estekatzen ditu: ");
			ema.getWebZerrenda().inprimatzailea();
			System.out.println(" Eta hurrengo hitz gakoak ditu: ");
			ema.inprimatuGakoak();
		}
	}

	private static int aukeratu() {
		return Teklatua.getTeklatua().intIrakurri("\nMENUA:\n"
				+ "1 -> web orri bat bilatu id-az\n"
				+ "2 -> web orri bat txertatu\n"
				+ "3 -> web orri bati esteka berria gehitu\n"
				+ "4 -> web orri bat ezabatu\n"
				+ "5 -> web baten web estekatuak itzuli\n"
				+ "6 -> gako hitz bat emanda web orriak bueltatu\n"
				+ "7 -> web orri zerrenda eguneratuta fitxategian gorde\n"
				+ "8 -> web orrien zerrenda alfabetikoki itzuli\n"
				+ "9 -> web orri bat bilatu url-az \n"
				+ "0 -> programatik irten\n", 9);
	}
}
